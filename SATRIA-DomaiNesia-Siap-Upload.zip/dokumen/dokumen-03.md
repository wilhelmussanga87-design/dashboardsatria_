# CHECKLIST ISIAN DATA DAN KERANGKA LAMPIRAN L-01 s.d. L-15 — SATRIA PUSLITBANG

Versi kerja untuk melengkapi isian draf LPP dan Paket Lampiran. Tanggal cek: **3 Oktober 2026**. Semua nilai yang "sudah tersedia" di bawah ini berasal dari arsip proyek (file di folder *data dukung* dan draf); tandai [PERIKSA] sebelum angka dipakai final.

## A. Prioritas menurut jadwal

| Sebelum | Data yang harus lengkap | Tujuan |
| --- | --- | --- |
| 4 Okt 2026 (uji coba M3) | Cakupan uji coba (unit, pengguna, paket); contoh Kartu Kendali terisi; checklist SOP | Lampiran L-06/L-07B; narasi LPP |
| 16 Okt 2026 (analisis evaluasi M4) | Hasil uji coba + angka; risk register terisi 1 siklus; IKPA/realisasi terbaru | L-05, L-07B/C; Bab III LPP |
| 28 Okt 2026 (penetapan M5) | Draf SK/nomor + tanggal penetapan SATRIA sebagai inovasi | L-04 (pengesahan SOP), L-11, Bab III |
| 9–10 Nov 2026 (kembali & sidang LPP) | LPP + seluruh lampiran + arsip bukti (log, foto, notulen) | Sidang LPP |

## B. Data yang sudah tersedia di arsip (tinggal disalin ke [ISI])

| Data | Nilai terdokumentasi | Sumber | Tujuan pengisian |
| --- | --- | --- | --- |
| Nama peserta | Wilhelmus Sanga, S.E., M.M. | LPP | Seluruh dokumen |
| NOSIS | 20260707010127 | LPP | LPP, L-13 |
| Jabatan | Kepala Urusan Keuangan Puslitbang Polri | LPP | LPP, L-02, L-11 |
| Diklat | PKN Tingkat II Angkatan XXVI Tahun 2026; Pusdikmin Polri; LAN RI | LPP | Seluruh dokumen |
| Coach | Dr. Wiharyani, S.P., M.Si., Pembina Utama Muda, NIP. 197907152009012005 — **TERVERIFIKASI** dari LEMBAR PERSETUJUAN RPP (tanda tangan 01 September 2026) | LPP | L-13, lembar persetujuan |
| Mentor | M. Budi Ariyanto, S.I.K., M.H., KOMBES POL, NRP. 74010610 — **TERVERIFIKASI** dari LEMBAR PERSETUJUAN RPP (tanda tangan 01 September 2026) | LPP | L-13, lembar persetujuan L-12 |
| Sponsor/Project Sponsor | Brigjen Pol. Didi Hayamansyah, S.H., S.I.K., M.H., Kapuslitbang Polri (jabatan dikonfirmasi sebagai "Mengetahui Atasan Langsung, Kepala Pusat Penelitian dan Pengembangan Polri" pada LEMBAR PERSETUJUAN RPP); penetapan/[PERIKSA] tetap mengikuti pengesahan LPP | LPP | L-02, L-08, L-09, L-12 |
| Nomor Sprin Tim Efektif & Tim Pokja | Tim Efektif: Sprin/1022/VIII/HUM.10.2/2026 (10 September 2026); Tim Pokja: Sprin/1021/VIII/HUM.10.2/2026 (31 Agustus 2026) | data dukung & Eviden | L-02, Matriks M1 |
| RPP dasar | Rancangan Proyek Perubahan final 03 September 2026; Grand Design PROPER PKN Tk II | Matriks/LPP | L-01, LPP Bab I |
| Periode off campus II | 10 September s.d. 8 November 2026 (60 hari) | Master Jadwal PKN ANGK XXVI | LPP Bab II, L-07 |
| Kembali ke Pusdikmin | 9 November 2026 (pembimbingan) | Master Jadwal | LPP, L-11 |
| Sidang LPP/seminar | 10 November 2026 (10 JP); Penutupan 12 Nov 2026 | Master Jadwal | LPP Bab II |
| Output dokumen | 01. SOP / 02. Risk Register / 03. Kartu Kendali (master & data isi) | Folder 3 Pilar Output | L-11, indeks bukti |
| Data realisasi anggaran | File "Realisasi Anggaran Puslitbang Polri Juli 2026.xlsx" dan "Realisasi Anggaran sd Juni 2026.pdf" | data dukung | L-03A D-01, L-07C |
| Pagu/realisasi agregat s.d. Juli 2026 | **TERVERIFIKASI (1 Oktober 2026)** dari xlsx: pagu **Rp333.636.862.000**; realisasi **Rp286.218.428.959** (**85,79%**); sisa **Rp47.418.433.041** — baris "GRAND TOTAL ANGGARAN PUSLITBANG POLRI TA 2026" | data dukung | L-03B, LPP Bab III |
| Indikator kinerja pelaksanaan anggaran | Nilai IKPA Februari–Juli 2026 (6 PDF): Feb 98,92 · Mar 95,63 · Apr 97,67 · Mei 96,08 · Jun 95,58 · Jul 94,38. **[TERVERIFIKASI 3 Oktober 2026]** — dikonfirmasi visual oleh penulis dari screenshot SPAN (PDF 204×206 px tidak terbaca OCR; nilai bukan rekaan) | data dukung | L-03A D-03, LPP Bab III |
| Monitoring kontrak/RPD | Monitoring Data Kontrak_2026-09-28.xlsx (7 kontrak, terpakai mengisi register L-03A D-02 dan L-03C); Monitoring RPD Halaman III DIPA_*.xlsx (rujukan analisis M4/L-05) | data dukung | L-05, LPP Bab III |
| Contoh Kartu Kendali | Kartu Kendali Bulanan bulan Juli 2026 (rujukan uji coba) | Matriks M3 | L-06, L-07B |

> PERHATIAN: Berkas **SPRIN Tim Efektif** dan **SPRIN Tim Pokja** kini tersedia (scan valid; juga di folder Eviden) — file kosong lama sudah diganti. Nomor SPRIN telah dikonfirmasi (Tim Efektif 1022, Tim Pokja 1021). Sebagian NRP/NIP pada scan kurang jelas — **verifikasi dengan dokumen asli** sebelum dipakai final.

## C. Pertanyaan data per lampiran

### L-01. Matriks Penyempurnaan Pascaseminar RPP
Yang sudah dapat diisikan (1 baris terdokumentasi):
- **Masukan:** Koreksi judul/tema oleh penguji pada sidang RPP menjadi *"Strategi Akselerasi Transformasi Tata Kelola Keuangan Berbasis Risiko melalui SATRIA Puslitbang"*.
- **Penyempurnaan:** Seluruh dokumen (LPP, Paket Lampiran, 3 output) diselaraskan ke judul baru.
- **Perlu diisi:** sumber/tanggal sidang RPP pasti; masukan lain dari penguji/Mentor/Coach; dampak pada produk/jadwal; kolom persetujuan.

### L-02. Pembentukan dan Pembagian Tugas Tim Efektif
- **Sudah terisi (data lengkap dari SPRIN Tim Efektif):** nomor & tanggal (Tim Efektif 10 September 2026; Tim Pokja 31 Agustus 2026), pejabat penerbit (Kapuslitbang), susunan personel Tim Efektif (7) lengkap beserta pangkat/NIP/jabatan, Tim Pokja (16), dasar (B/509/…/Pusdikmin 21-8-2026) — lihat kerangka pada `02. Paket Draf…` L-02.
- **Selesai:** tidak ada verifikasi tersisa untuk data personel Tim Efektif.

### L-03. Baseline dan Inventarisasi Paket
- **A. Register sumber:** **D-01 dan D-02 sudah terisi** dari file sumber (*Realisasi Anggaran Puslitbang Polri Juli 2026 06082026.xlsx*; *Monitoring Data Kontrak_2026-09-28 22-44.xlsx* — 7 kontrak; catatan D-02 telah dikoreksi: kontrak lab Maracipta Utama SPPB/1=99.751.680.000, SPPB/2=99.716.800.000, SPPB/3=99.749.700.000, total 299.218.180.000). **D-03 (IKPA) sudah terverifikasi 3 Oktober 2026**: Feb 98,92; Mar 95,63; Apr 97,67; Mei 96,08; Jun 95,58; Jul 94,38 — dikonfirmasi visual oleh penulis dari screenshot SPAN (6 PDF; citra 204×206 px tidak terbaca OCR, nilai bukan rekaan).
- **B. Matriks baseline:** isi *kondisi awal + tanggal* untuk: (1) kesiapan paket (pembilang/penyebut), (2) penerapan Kartu Kendali (target 100% sasaran sesuai RPP — tentukan *jumlah sasaran*), (3) tindak lanjut tepat waktu (ukuran awal → target).
- **C. Inventarisasi paket pengadaan dini:** **sudah terisi 6 paket sasaran** (1 Oktober 2026) dari Kartu Kendali Bulanan KPA Juli 2026 (data dukung "3 Pilar Output - data isi") yang memuat pagu, target, realisasi, deviasi dan PPK per paket, dilengkapi nomor kontrak dari OM-SPAN monitoring kontrak unduh 28-09-2026. Paket sasaran: (1) Peralatan Uji Laboratorium Litbangyasa 3 paket/PPK KBP Caterina, (2) Pemeliharaan Gedung/IPTU Kristo, (3) Pemeliharaan Peralatan Fungsional/IPTU Kristo, (4) Jasa Keamanan & Kebersihan/AKP Handono, (5) SPBE & Website/AKBP Septi, (6) Pemeliharaan Kendaraan & Peralatan Kantor/AKP Gustika. **Sisa [PERIKSA] (2 butir, butuh konfirmasi Urkeu/PPK):** (1) rekonsiliasi selisih pagu Rp895.864.000 vs nilai kontrak SPPB/30/II/2026 Rp748.140.000 (selisih Rp147.724.000) pada baris 5; (2) nomor dokumen dan metode pengadaan paket rutin kendaraan/peralatan kantor (baris 6) karena tidak tercantum pada ekspor monitoring kontrak OM-SPAN 28-09-2026.

### L-04. Draf Substansi SOP SATRIA
- **Perlu diisi:** tanggal penyusunan (rujukan: draf output M2 22 Sep 2026), tanggal revisi/efektif, pejabat pengesah, nomor SOP `[VERIFIKASI NOMOR]`.
- **Perlu ditetapkan [TETAPKAN]:** standar waktu langkah 2 (pemeriksaan kesiapan) dan langkah 4 (penetapan mitigasi) pada tabel alur.
- **Perlu dilengkapi:** dasar hukum berlakunya (pengadaan, pelaksanaan anggaran, manajemen risiko, tata naskah); hasil telaah hubungan dengan SOP Pencairan Anggaran Kontraktual Juni 2025.
- **Pengesahan:** Disusun oleh `[ISI]` (pengelola SOP), Ditelaah oleh `[ISI pejabat terkait]`, Disahkan oleh `[ISI pejabat berwenang]` + nomor/tanggal.

### L-05. Risk Register Kinerja
- **Perlu diisi:** periode, unit/pemilik proses, metodologi (skala & ambang warna) + persetujuannya.
- **R-01/R-02:** isi dari tema risiko RPP yang diuji: kesiapan dokumen, keraguan pelaksana, transisi/mutasi personel, keterbatasan waktu. Masing-masing: sebab, dampak, pengendalian ada, kemungkinan/dampak/level, pemilik, mitigasi+tenggat, status/bukti.
- **Pertanyaan kunci:** risiko nyata apa yang terjadi selama off campus (dari log/monitoring)? Nilai IKPA & data kontrak menjadi bukti status.

### L-06. Kartu Kendali Bulanan KPA
- Gunakan **pola Kartu Kendali Bulan Juli 2026** (sudah ada di arsip) sebagai contoh baris terisi.
- **Perlu diisi:** periode (contoh: Juli 2026 / Agustus–Oktober 2026), unit, tanggal pembaruan, penyusun/pemeriksa; baris kegiatan/paket dengan target→realisasi→deviasi→warna→arahan KPA→hasil.
- **Form pelaporan risiko merah:** isi bila ada kejadian yang benar-benar terjadi; tanggal/paraf arahan KPA setelah pemeriksaan.

### L-07. Validasi, Uji Coba dan Evaluasi
- **A. Berita acara pembahasan:** tanggal/tempat/agenda; peserta (daftar hadir); pokok bahasan, masukan, keputusan, perbaikan, PIC & tenggat — diisi **setelah** rapat/validasi berlangsung.
- **B. Form uji coba (3 skenario):** kesiapan paket, pengisian risiko, Kartu Kendali — hasil aktual, kendala, perbaikan/PIC, verifikasi ulang. Label simulasi bila simulasi. **Disi setelah 4 Okt 2026.**
- **C. Evaluasi manfaat:** sebelum/sesudah untuk kesiapan dokumen, ketepatan pelaporan, tindak lanjut tepat waktu + faktor lain + bukti. Angka awal dari baseline L-03; angka sesudah dari hasil uji coba.

### L-08. Dukungan Stakeholder dan Komitmen Kerja Bersama
- **Pernyataan dukungan:** nama/jabatan/unit, bentuk dukungan konkret, PIC/tindak lanjut, tempat/tanggal + tanda tangan. Calon pihak: Sponsor (Kapuslitbang), Mentor, PPK, BPP/pengelola.
- **KKB:** cakupan paket/unit, jadwal pembaruan, mekanisme evaluasi & eskalasi; tabel nama/jabatan/unit + peran + tanda tangan.

### L-09. Pemetaan Stakeholder
- **Perlu diisi:** tabel stakeholder (Sponsor, Mentor, PPK, BPP/pengelola, pimpinan/pengguna, eksternal bila ada) dengan peran, pengaruh/kepentingan awal, posisi awal, dukungan aktual/bukti, posisi akhir, dasar perubahan.
- Lampirkan netmap + gambar kuadran; cantumkan tanggal penilaian awal/akhir dan pihak yang memvalidasi.

### L-10. Pengembangan Kompetensi
- **Yang sudah dapat diisi:** kegiatan PKN Tk II (mata pelatihan di Pusdikmin + praktik off campus) [PERIKSA nama/susunan mata pelatihan resmi], Project Leader → kolaborasi/komunikasi.
- **Perlu diisi:** tanggal kegiatan, hasil belajar, contoh penerapan pada produk/proses, bukti (materi, sertifikat, catatan pendampingan).

### L-11. Berita Acara Penyerahan Hasil
- **Waktu alami:** setelah penetapan (M5, 28 Okt) dan kembali ke Pusdikmin (9 Nov 2026).
- **Perlu diisi:** nomor BA sesuai tata naskah, hari/tanggal/tempat, nama/jabatan pejabat penerima, nomor/tanggal pengesahan tiap produk, bentuk/jumlah/lokasi arsip, catatan penerimaan, tindak lanjut + kekurangan.

### L-12. Pernyataan Keberlanjutan
- **Perlu diisi:** ruang lingkup; tabel kegiatan lanjutan (pemeliharaan instrumen, pengawalan kesiapan pengadaan, evaluasi Semester I berikutnya, kajian perluasan/replikasi) dengan penanggung jawab, waktu, dukungan sumber daya, indikator, pelaporan.
- Penandatangan: Kasatker, Mentor, Peserta, Saksi 1–2 + tempat/tanggal.

### L-13. Lembar Konsultasi Mentor/Coach
- **Dapat diisikan mulai sekarang:** konsultasi yang telah berlangsung (log minggu 1–2, tanggal ±16 September 2026 ke atas): tanggal, materi, arahan, tindak lanjut+tenggat, hasil; paraf pembimbing `[DIISI PEMBIMBING]`.
- **Perlu dipertahankan:** bukti pembimbingan (surat/WA/daftar hadir) sampai 8 November 2026.

### L-14 dan L-15. Penempatan Arsip Tahap Berikutnya
- Himpun setelah penyusunan draf: log harian/mingguan, foto, daftar hadir, notulen, bukti komunikasi, publikasi, video/testimoni ≤10 menit, bahan tayang.
- **Indeks bukti:** setiap baris = kode bukti, tanggal kegiatan, uraian, nama file/lokasi, bagian LPP/lampiran terkait, status pemeriksaan. Data yang disebut dalam narasi LPP **wajib** tertelusur di indeks ini.

## D. Ringkasan pertanyaan data terpenting (nomor untuk dijawab)

1. Tanggal & nomor lengkap Sprin Tim Efektif + susunan personel? (L-02)
2. Berapa **paket sasaran** pengadaan dini TA 2026 dan mana yang sudah siap? (L-03C)
3. Nilai **kondisi awal** kesiapan paket, penerapan Kartu Kendali, tindak lanjut tepat waktu? (L-03B)
4. Metodologi Risk Register (skala/ambang warna) yang disepakati? (L-05)
5. Cakupan uji coba unit/pengguna/paket? (LPP Bab II, L-07B)
6. Nomor/tanggal **penetapan SATRIA sebagai inovasi**? (Matriks M5, LPP Bab III)
7. Nomor/tanggal **pengesahan SOP** + pejabat pengesah? (L-04)
8. Nama/jabatan **pejabat penerima** hasil (untuk BA penyerahan)? (L-11)
9. Nilai IKPA & realisasi **Agustus–Oktober 2026** (perbaruan terakhir)? (L-03A, LPP Bab III)
10. Identitas resmi Coach/Mentor/pejabat saat pengesahan? (LPP lembar persetujuan)
